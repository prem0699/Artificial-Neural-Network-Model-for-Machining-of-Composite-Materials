function input_norm = normalize(z)
input_norm=(z-min(z))/range(z);
%UNTITLED6 Summary of this function goes here

end

