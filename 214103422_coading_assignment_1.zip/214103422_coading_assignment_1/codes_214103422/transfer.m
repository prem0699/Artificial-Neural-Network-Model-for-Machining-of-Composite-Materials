function tf = transfer(ls)
tf=1./(1+exp(-ls));
end

